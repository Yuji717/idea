const base = {
    get() {
        return {
            url : "http://localhost:8080/springboots23q6/",
            name: "springboots23q6",
            // 退出到首页链接
            indexUrl: ''
        };
    },
    getProjectName(){
        return {
            projectName: "培养方案管理系统"
        } 
    }
}
export default base
