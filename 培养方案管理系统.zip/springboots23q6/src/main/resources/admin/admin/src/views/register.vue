<template>
  <div>
        <div class="container">
      <div class="login-form">
        <h1 class="h1">培养方案管理系统注册</h1>
		<el-form ref="rgsForm" class="rgs-form" :model="rgsForm">
			<!-- <div v-if="tableName=='zhuanyefuzeren'" class="input-group">
			   <div class="label">密码</div>
			   <div class="input-container">
			     <input v-model="ruleForm.mima" class="input" type="text" placeholder="密码">
			   </div>
			 </div> -->
			<el-form-item label="密码" class="input" v-if="tableName=='zhuanyefuzeren'">
			  <el-input v-model="ruleForm.mima" autocomplete="off" placeholder="密码" type="password"#elsetype="text" />
			</el-form-item>
			<el-form-item label="确认密码" class="input" v-if="tableName=='zhuanyefuzeren'">
			  <el-input v-model="ruleForm.mima2" autocomplete="off" placeholder="确认密码" type="password"/>
			</el-form-item>

			<!-- <div v-if="tableName=='zhuanyefuzeren'" class="input-group">
			   <div class="label">负责人姓名</div>
			   <div class="input-container">
			     <input v-model="ruleForm.fuzerenxingming" class="input" type="text" placeholder="负责人姓名">
			   </div>
			 </div> -->
			<el-form-item label="负责人姓名" class="input" v-if="tableName=='zhuanyefuzeren'">
			  <el-input v-model="ruleForm.fuzerenxingming" autocomplete="off" placeholder="负责人姓名"  />
			</el-form-item>
			<!-- <div v-if="tableName=='zhuanyefuzeren'" class="input-group">
			   <div class="label">职位</div>
			   <div class="input-container">
			     <input v-model="ruleForm.zhiwei" class="input" type="text" placeholder="职位">
			   </div>
			 </div> -->
			<el-form-item label="职位" class="input" v-if="tableName=='zhuanyefuzeren'">
			  <el-input v-model="ruleForm.zhiwei" autocomplete="off" placeholder="职位"  />
			</el-form-item>
			<!-- <div v-if="tableName=='zhuanyefuzeren'" class="input-group">
			   <div class="label">联系方式</div>
			   <div class="input-container">
			     <input v-model="ruleForm.lianxifangshi" class="input" type="text" placeholder="联系方式">
			   </div>
			 </div> -->
			<el-form-item label="联系方式" class="input" v-if="tableName=='zhuanyefuzeren'">
			  <el-input v-model="ruleForm.lianxifangshi" autocomplete="off" placeholder="联系方式"  />
			</el-form-item>
			<!-- <div v-if="tableName=='jiaoshi'" class="input-group">
			   <div class="label">教师工号</div>
			   <div class="input-container">
			     <input v-model="ruleForm.jiaoshigonghao" class="input" type="text" placeholder="教师工号">
			   </div>
			 </div> -->
			<el-form-item label="教师工号" class="input" v-if="tableName=='jiaoshi'">
			  <el-input v-model="ruleForm.jiaoshigonghao" autocomplete="off" placeholder="教师工号"  />
			</el-form-item>
			<!-- <div v-if="tableName=='jiaoshi'" class="input-group">
			   <div class="label">密码</div>
			   <div class="input-container">
			     <input v-model="ruleForm.mima" class="input" type="text" placeholder="密码">
			   </div>
			 </div> -->
			<el-form-item label="密码" class="input" v-if="tableName=='jiaoshi'">
			  <el-input v-model="ruleForm.mima" autocomplete="off" placeholder="密码" type="password"#elsetype="text" />
			</el-form-item>
			<el-form-item label="确认密码" class="input" v-if="tableName=='jiaoshi'">
			  <el-input v-model="ruleForm.mima2" autocomplete="off" placeholder="确认密码" type="password"/>
			</el-form-item>

			<!-- <div v-if="tableName=='jiaoshi'" class="input-group">
			   <div class="label">教师姓名</div>
			   <div class="input-container">
			     <input v-model="ruleForm.jiaoshixingming" class="input" type="text" placeholder="教师姓名">
			   </div>
			 </div> -->
			<el-form-item label="教师姓名" class="input" v-if="tableName=='jiaoshi'">
			  <el-input v-model="ruleForm.jiaoshixingming" autocomplete="off" placeholder="教师姓名"  />
			</el-form-item>
			<!-- <div v-if="tableName=='jiaoshi'" class="input-group">
			   <div class="label">职称</div>
			   <div class="input-container">
			     <input v-model="ruleForm.zhicheng" class="input" type="text" placeholder="职称">
			   </div>
			 </div> -->
			<el-form-item label="职称" class="input" v-if="tableName=='jiaoshi'">
			  <el-input v-model="ruleForm.zhicheng" autocomplete="off" placeholder="职称"  />
			</el-form-item>
			<!-- <div v-if="tableName=='jiaoshi'" class="input-group">
			   <div class="label">联系电话</div>
			   <div class="input-container">
			     <input v-model="ruleForm.lianxidianhua" class="input" type="text" placeholder="联系电话">
			   </div>
			 </div> -->
			<el-form-item label="联系电话" class="input" v-if="tableName=='jiaoshi'">
			  <el-input v-model="ruleForm.lianxidianhua" autocomplete="off" placeholder="联系电话"  />
			</el-form-item>
			<div style="display: flex;flex-wrap: wrap;width: 100%;justify-content: center;">
				<el-button class="btn" type="primary" @click="login()">注册</el-button>
				<el-button class="btn close" type="primary" @click="close()">取消</el-button>
			</div>
		</el-form>
      </div>
      <!-- <div class="nk-navigation">
        <a href="#">
          <div @click="login()">注册</div>
        </a>
      </div> -->
    </div>
  </div>
</template>
<script>


export default {
  data() {
    return {
      ruleForm: {
      },
      tableName:"",
      rules: {},
    };
  },
  mounted(){
    let table = this.$storage.get("loginTable");
    this.tableName = table;
      },
  created() {
    
  },
  methods: {
    // 获取uuid
    getUUID () {
      return new Date().getTime();
    },
    close(){
	this.$router.push({ path: "/login" });
    },
    // 注册
    login() {
	var url=this.tableName+"/register";
      if((!this.ruleForm.fuzerenzhanghao) && `zhuanyefuzeren` == this.tableName){
        this.$message.error(`负责人账号不能为空`);
        return
      }
      if((!this.ruleForm.mima) && `zhuanyefuzeren` == this.tableName){
        this.$message.error(`密码不能为空`);
        return
      }
      if((this.ruleForm.mima!=this.ruleForm.mima2) && `zhuanyefuzeren` == this.tableName){
	    this.$message.error(`两次密码输入不一致`);
	    return
      }
      if((!this.ruleForm.fuzerenxingming) && `zhuanyefuzeren` == this.tableName){
        this.$message.error(`负责人姓名不能为空`);
        return
      }
      if(`zhuanyefuzeren` == this.tableName && this.ruleForm.lianxifangshi&&(!this.$validate.isMobile(this.ruleForm.lianxifangshi))){
        this.$message.error(`联系方式应输入手机格式`);
        return
      }
      if((!this.ruleForm.jiaoshigonghao) && `jiaoshi` == this.tableName){
        this.$message.error(`教师工号不能为空`);
        return
      }
      if((!this.ruleForm.mima) && `jiaoshi` == this.tableName){
        this.$message.error(`密码不能为空`);
        return
      }
      if((this.ruleForm.mima!=this.ruleForm.mima2) && `jiaoshi` == this.tableName){
	    this.$message.error(`两次密码输入不一致`);
	    return
      }
      if((!this.ruleForm.jiaoshixingming) && `jiaoshi` == this.tableName){
        this.$message.error(`教师姓名不能为空`);
        return
      }
      if((!this.ruleForm.zhuanye) && `jiaoshi` == this.tableName){
        this.$message.error(`专业不能为空`);
        return
      }
      if((!this.ruleForm.nianji) && `jiaoshi` == this.tableName){
        this.$message.error(`年级不能为空`);
        return
      }
      if(`jiaoshi` == this.tableName && this.ruleForm.lianxidianhua&&(!this.$validate.isMobile(this.ruleForm.lianxidianhua))){
        this.$message.error(`联系电话应输入手机格式`);
        return
      }
      this.$http({
        url: url,
        method: "post",
        data:this.ruleForm
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.$message({
            message: "注册成功",
            type: "success",
            duration: 1500,
            onClose: () => {
              this.$router.replace({ path: "/login" });
            }
          });
        } else {
          this.$message.error(data.msg);
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
	.el-radio__input.is-checked .el-radio__inner {
		border-color: #00c292;
		background: #00c292;
	}

	.el-radio__input.is-checked .el-radio__inner {
		border-color: #00c292;
		background: #00c292;
	}

	.el-radio__input.is-checked .el-radio__inner {
		border-color: #00c292;
		background: #00c292;
	}

	.el-radio__input.is-checked+.el-radio__label {
		color: #00c292;
	}

	.el-radio__input.is-checked+.el-radio__label {
		color: #00c292;
	}

	.el-radio__input.is-checked+.el-radio__label {
		color: #00c292;
	}

	.h1 {
		margin-top: 10px;
	}

	body {
		padding: 0;
		margin: 0;
	}

	// .container {
 //    min-height: 100vh;
 //    text-align: center;
 //    // background-color: #00c292;
 //    padding-top: 20vh;
 //    background-image: url(../assets/img/bg.jpg);
 //    background-size: 100% 100%;
 //    opacity: 0.9;
 //  }

	// .login-form:before {
	// 	vertical-align: middle;
	// 	display: inline-block;
	// }

	// .login-form {
	// 	max-width: 500px;
	// 	padding: 20px 0;
	// 	width: 80%;
	// 	position: relative;
	// 	margin: 0 auto;

	// 	.label {
	// 		min-width: 60px;
	// 	}

	// 	.input-group {
	// 		max-width: 500px;
	// 		padding: 20px 0;
	// 		width: 80%;
	// 		position: relative;
	// 		margin: 0 auto;
	// 		display: flex;
	// 		align-items: center;

	// 		.input-container {
	// 			display: inline-block;
	// 			width: 100%;
	// 			text-align: left;
	// 			margin-left: 10px;
	// 		}

	// 		.icon {
	// 			width: 30px;
	// 			height: 30px;
	// 		}

	// 		.input {
	// 			position: relative;
	// 			z-index: 2;
	// 			float: left;
	// 			width: 100%;
	// 			margin-bottom: 0;
	// 			box-shadow: none;
	// 			border-top: 0px solid #ccc;
	// 			border-left: 0px solid #ccc;
	// 			border-right: 0px solid #ccc;
	// 			border-bottom: 1px solid #ccc;
	// 			padding: 0px;
	// 			resize: none;
	// 			border-radius: 0px;
	// 			display: block;
	// 			width: 100%;
	// 			height: 34px;
	// 			padding: 6px 12px;
	// 			font-size: 14px;
	// 			line-height: 1.42857143;
	// 			color: #555;
	// 			background-color: #fff;
	// 		}

	// 	}
	// }

	.nk-navigation {
		margin-top: 15px;

		a {
			display: inline-block;
			color: #fff;
			background: rgba(255, 255, 255, .2);
			width: 100px;
			height: 50px;
			border-radius: 30px;
			text-align: center;
			display: flex;
			align-items: center;
			margin: 0 auto;
			justify-content: center;
			padding: 0 20px;
		}

		.icon {
			margin-left: 10px;
			width: 30px;
			height: 30px;
		}
	}

	.register-container {
		margin-top: 10px;

		a {
			display: inline-block;
			color: #fff;
			max-width: 500px;
			height: 50px;
			border-radius: 30px;
			text-align: center;
			display: flex;
			align-items: center;
			margin: 0 auto;
			justify-content: center;
			padding: 0 20px;

			div {
				margin-left: 10px;
			}
		}
	}

	.container {
		height: 100vh;
		background-position: center center;
		background-size: cover;
		background-repeat: no-repeat;
    				background-image: url(http://codegen.caihongy.cn/20211104/0d708b599e614301a43ac8d3dbcfa864.jpg);
		    
		.login-form {
			right: 50%;
			top: 50%;
			transform: translate3d(50%, -50%, 0);
			border-radius: 10px;
			background-color: rgba(255,255,255,.5);
			font-size: 14px;
			font-weight: 500;
      box-sizing: border-box;

			width: 430px;
			height: auto;
			padding: 15px;
			margin: 0px 0px 0px -10px;
			border-radius: 0;
			border-width: 4px;
			border-style: dotted;
			border-color: rgba(74, 50, 22, 1);
			background-color: rgba(253, 253, 229, 1);
			box-shadow: 0px 0px 0px 15px rgba(253, 253, 229, 1);

			.h1 {
				width: 400px;
				height: 32px;
				line-height:32px;
				color: rgba(74, 50, 22, 1);
				font-size: 18px;
				padding: 0px 0px 0px 0px;
				margin: 0px 0px 20px -20px;
				border-radius: 0;
				border-width: 0;
				border-style: dotted;
				border-color: rgba(255, 255, 255, 1);
				background-color: rgba(255, 215, 0, 0);
				box-shadow: 0px 0px 0px 0px rgba(74, 50, 22, 1);
				text-align: center;
			}

			.rgs-form {
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;

        .el-form-item {
          width: 100%;
          display: flex;

          & /deep/ .el-form-item__content {
            flex: 1;
            display: flex;
          }
        }

				.input {
          width: 320px;
          height:auto;
          padding: 0px 0px 0px 0px;
          margin: 0px 0px 10px -30px;
          border-radius: 0;
          border-width: 0;
          border-style: solid;
          border-color: rgba(255,0,0,0);
          background-color: rgba(30, 144, 255, 0);
          box-shadow: 0 0 6px rgba(255,0,0,0);

					& /deep/ .el-form-item__label {
            width: 120px;
            line-height:42px;
            color: rgba(0, 0, 0, 1);
            font-size: 14px;
            padding: 0px 0px 0px 0px;
            margin: 0px 10px 0px 10px;
            border-radius: 0;
            border-width: 0;
            border-style: solid;
            border-color: rgba(255,0,0,0);
            background-color: rgba(255, 215, 0, 0);
            box-shadow: 0 0 6px rgba(255,0,0,0);
					}

					& /deep/ .el-input__inner {
            width: 220px;
            height: 40px;
            line-height:40px;
            color: rgba(0, 0, 0, 1);
            font-size: 14px;
            padding: 0px 0px 0px 15px;
            margin: 0px 0px 0px 0px;
            border-radius: 4px;
            border-width: 2px;
            border-style: dotted;
            border-color: rgba(74, 50, 22, 1);
            background-color: rgba(253, 253, 229, 1);
            box-shadow: 0 0 6px rgba(255,0,0,0);
            text-align: left;
					}
				}

        .send-code {
          & /deep/ .el-input__inner {
            width: 135px;
            height: 40px;
            line-height:40px;
            color: #606266;
            font-size: 14px;
            padding: 0px 0px 0px 10px;
            margin: 0px 0px 0px 0px;
            border-radius: 4px 0px 0px 4px;
            border-width: 2px;
            border-style: dotted;
            border-color: rgba(74, 50, 22, 1);
            background-color: rgba(253, 253, 229, 1);
            box-shadow: 0 0 6px rgba(255,0,0,0);
            text-align: left;
          }

          .register-code {
            margin: 0;
            padding: 0;
            width: 86px;
            height: 40px;
            line-height:40px;
            color: #fff;
            font-size: 14px;
            border-width: 0;
            border-style: solid;
            border-color: rgba(255,0,0,0);
            border-radius: 0;
            background-color: rgba(74, 50, 22, 1);
            box-shadow: 0 0 6px rgba(255,0,0,0);
          }
        }

				.btn {
					margin: 10px 0px 0px 5px;
          padding: 0;
					width: 88px;
					height: 40px;
          line-height:40px;
					color: #fff;
					font-size: 14px;
					border-width: 0;
					border-style: solid;
					border-color: #409EFF;
					border-radius: 4px;
					background-color: rgba(74, 50, 22, 1);
          box-shadow: 0 0 6px rgba(255,0,0,0);
				}

				.close {
          margin: 10px 0px 0px 20px;
          padding: 0px 0px 0px 0px;
          width: 88px;
          height: 40px;
          line-height:40px;
          color: rgba(255, 255, 255, 1);
          font-size: 14px;
          border-width: 0;
          border-style: solid;
          border-color: #409EFF;
          border-radius: 4px;
          background-color: rgba(74, 50, 22, 1);
          box-shadow: 0 0 6px rgba(255,0,0,0);
				}

			}
		}
	}
</style>
