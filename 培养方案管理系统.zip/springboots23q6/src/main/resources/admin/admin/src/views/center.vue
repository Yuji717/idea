<template>
  <div>
    <el-form
      class="detail-form-content"
      ref="ruleForm"
      :model="ruleForm"
      label-width="80px"
	  style="background: transparent;"
    >  
     <el-row>
      <el-col :span="12">
        <el-form-item   v-if="flag=='zhuanyefuzeren'"  label="负责人账号" prop="fuzerenzhanghao">
          <el-input v-model="ruleForm.fuzerenzhanghao" readonly              placeholder="负责人账号" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item   v-if="flag=='zhuanyefuzeren'"  label="负责人姓名" prop="fuzerenxingming">
          <el-input v-model="ruleForm.fuzerenxingming"               placeholder="负责人姓名" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item v-if="flag=='zhuanyefuzeren'"  label="性别" prop="xingbie">
          <el-select v-model="ruleForm.xingbie"  placeholder="请选择性别">
            <el-option
                v-for="(item,index) in zhuanyefuzerenxingbieOptions"
                v-bind:key="index"
                :label="item"
                :value="item">
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item v-if="flag=='zhuanyefuzeren'"  label="专业" prop="zhuanye">
          <el-select v-model="ruleForm.zhuanye" :disabled="true" placeholder="请选择专业">
            <el-option
                v-for="(item,index) in zhuanyefuzerenzhuanyeOptions"
                v-bind:key="index"
                :label="item"
                :value="item">
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item   v-if="flag=='zhuanyefuzeren'"  label="职位" prop="zhiwei">
          <el-input v-model="ruleForm.zhiwei"               placeholder="职位" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item   v-if="flag=='zhuanyefuzeren'"  label="联系方式" prop="lianxifangshi">
          <el-input v-model="ruleForm.lianxifangshi"               placeholder="联系方式" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item   v-if="flag=='jiaoshi'"  label="教师工号" prop="jiaoshigonghao">
          <el-input v-model="ruleForm.jiaoshigonghao" readonly              placeholder="教师工号" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item   v-if="flag=='jiaoshi'"  label="教师姓名" prop="jiaoshixingming">
          <el-input v-model="ruleForm.jiaoshixingming"               placeholder="教师姓名" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item v-if="flag=='jiaoshi'"  label="性别" prop="xingbie">
          <el-select v-model="ruleForm.xingbie"  placeholder="请选择性别">
            <el-option
                v-for="(item,index) in jiaoshixingbieOptions"
                v-bind:key="index"
                :label="item"
                :value="item">
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item v-if="flag=='jiaoshi'"  label="专业" prop="zhuanye">
          <el-select v-model="ruleForm.zhuanye" :disabled="true" placeholder="请选择专业">
            <el-option
                v-for="(item,index) in jiaoshizhuanyeOptions"
                v-bind:key="index"
                :label="item"
                :value="item">
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item v-if="flag=='jiaoshi'"  label="年级" prop="nianji">
          <el-select v-model="ruleForm.nianji"  placeholder="请选择年级">
            <el-option
                v-for="(item,index) in jiaoshinianjiOptions"
                v-bind:key="index"
                :label="item"
                :value="item">
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item   v-if="flag=='jiaoshi'"  label="职称" prop="zhicheng">
          <el-input v-model="ruleForm.zhicheng"               placeholder="职称" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item   v-if="flag=='jiaoshi'"  label="联系电话" prop="lianxidianhua">
          <el-input v-model="ruleForm.lianxidianhua"               placeholder="联系电话" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item   v-if="flag=='jiaoshi'"  label="负责人账号" prop="fuzerenzhanghao">
          <el-input v-model="ruleForm.fuzerenzhanghao" readonly              placeholder="负责人账号" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-form-item v-if="flag=='users'" label="用户名" prop="username">
        <el-input v-model="ruleForm.username" 
        placeholder="用户名"></el-input>
      </el-form-item>
      <el-col :span="24">
      <el-form-item>
        <el-button type="primary" @click="onUpdateHandler">修 改</el-button>
      </el-form-item>
      </el-col>
      </el-row>
    </el-form>
  </div>
</template>
<script>
// 数字，邮件，手机，url，身份证校验
import { isNumber,isIntNumer,isEmail,isMobile,isPhone,isURL,checkIdCard } from "@/utils/validate";

export default {
  data() {
    return {
      ruleForm: {},
      flag: '',
      usersFlag: false,
      zhuanyefuzerenxingbieOptions: [],
      zhuanyefuzerenzhuanyeOptions: [],
      jiaoshixingbieOptions: [],
      jiaoshizhuanyeOptions: [],
      jiaoshinianjiOptions: [],
    };
  },
  mounted() {
    var table = this.$storage.get("sessionTable");
    this.flag = table;
    this.$http({
      url: `${this.$storage.get("sessionTable")}/session`,
      method: "get"
    }).then(({ data }) => {
      if (data && data.code === 0) {
        this.ruleForm = data.data;
      } else {
        this.$message.error(data.msg);
      }
    });
    this.zhuanyefuzerenxingbieOptions = "男,女".split(',')
    this.$http({
      url: `option/zhuanye/zhuanye`,
      method: "get"
    }).then(({ data }) => {
      if (data && data.code === 0) {
        this.zhuanyefuzerenzhuanyeOptions = data.data;
      } else {
        this.$message.error(data.msg);
      }
    });
    this.jiaoshixingbieOptions = "男,女".split(',')
    this.$http({
      url: `option/zhuanye/zhuanye`,
      method: "get"
    }).then(({ data }) => {
      if (data && data.code === 0) {
        this.jiaoshizhuanyeOptions = data.data;
      } else {
        this.$message.error(data.msg);
      }
    });
    this.$http({
      url: `option/nianji/nianji`,
      method: "get"
    }).then(({ data }) => {
      if (data && data.code === 0) {
        this.jiaoshinianjiOptions = data.data;
      } else {
        this.$message.error(data.msg);
      }
    });
  },
  methods: {
    onUpdateHandler() {
      if((!this.ruleForm.fuzerenzhanghao)&& 'zhuanyefuzeren'==this.flag){
        this.$message.error('负责人账号不能为空');
        return
      }
      if((!this.ruleForm.mima)&& 'zhuanyefuzeren'==this.flag){
        this.$message.error('密码不能为空');
        return
      }
      if((!this.ruleForm.fuzerenxingming)&& 'zhuanyefuzeren'==this.flag){
        this.$message.error('负责人姓名不能为空');
        return
      }
      if( 'zhuanyefuzeren' ==this.flag && this.ruleForm.lianxifangshi&&(!isMobile(this.ruleForm.lianxifangshi))){
        this.$message.error(`联系方式应输入手机格式`);
        return
      }
      if((!this.ruleForm.jiaoshigonghao)&& 'jiaoshi'==this.flag){
        this.$message.error('教师工号不能为空');
        return
      }
      if((!this.ruleForm.mima)&& 'jiaoshi'==this.flag){
        this.$message.error('密码不能为空');
        return
      }
      if((!this.ruleForm.jiaoshixingming)&& 'jiaoshi'==this.flag){
        this.$message.error('教师姓名不能为空');
        return
      }
      if((!this.ruleForm.zhuanye)&& 'jiaoshi'==this.flag){
        this.$message.error('专业不能为空');
        return
      }
      if((!this.ruleForm.nianji)&& 'jiaoshi'==this.flag){
        this.$message.error('年级不能为空');
        return
      }
      if( 'jiaoshi' ==this.flag && this.ruleForm.lianxidianhua&&(!isMobile(this.ruleForm.lianxidianhua))){
        this.$message.error(`联系电话应输入手机格式`);
        return
      }
      if('users'==this.flag && this.ruleForm.username.trim().length<1) {
	this.$message.error(`用户名不能为空`);
        return	
      }
      this.$http({
        url: `${this.$storage.get("sessionTable")}/update`,
        method: "post",
        data: this.ruleForm
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.$message({
            message: "修改信息成功",
            type: "success",
            duration: 1500,
            onClose: () => {
            }
          });
        } else {
          this.$message.error(data.msg);
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
</style>
