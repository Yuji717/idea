package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ZhuanyefuzerenDao;
import com.entity.ZhuanyefuzerenEntity;
import com.service.ZhuanyefuzerenService;
import com.entity.vo.ZhuanyefuzerenVO;
import com.entity.view.ZhuanyefuzerenView;

@Service("zhuanyefuzerenService")
public class ZhuanyefuzerenServiceImpl extends ServiceImpl<ZhuanyefuzerenDao, ZhuanyefuzerenEntity> implements ZhuanyefuzerenService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ZhuanyefuzerenEntity> page = this.selectPage(
                new Query<ZhuanyefuzerenEntity>(params).getPage(),
                new EntityWrapper<ZhuanyefuzerenEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ZhuanyefuzerenEntity> wrapper) {
		  Page<ZhuanyefuzerenView> page =new Query<ZhuanyefuzerenView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ZhuanyefuzerenVO> selectListVO(Wrapper<ZhuanyefuzerenEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ZhuanyefuzerenVO selectVO(Wrapper<ZhuanyefuzerenEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ZhuanyefuzerenView> selectListView(Wrapper<ZhuanyefuzerenEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ZhuanyefuzerenView selectView(Wrapper<ZhuanyefuzerenEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
