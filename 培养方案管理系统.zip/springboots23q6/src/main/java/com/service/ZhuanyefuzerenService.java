package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ZhuanyefuzerenEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ZhuanyefuzerenVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ZhuanyefuzerenView;


/**
 * 专业负责人
 *
 * @author 
 * @email 
 * @date 2022-04-19 21:55:27
 */
public interface ZhuanyefuzerenService extends IService<ZhuanyefuzerenEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ZhuanyefuzerenVO> selectListVO(Wrapper<ZhuanyefuzerenEntity> wrapper);
   	
   	ZhuanyefuzerenVO selectVO(@Param("ew") Wrapper<ZhuanyefuzerenEntity> wrapper);
   	
   	List<ZhuanyefuzerenView> selectListView(Wrapper<ZhuanyefuzerenEntity> wrapper);
   	
   	ZhuanyefuzerenView selectView(@Param("ew") Wrapper<ZhuanyefuzerenEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ZhuanyefuzerenEntity> wrapper);
   	

}

