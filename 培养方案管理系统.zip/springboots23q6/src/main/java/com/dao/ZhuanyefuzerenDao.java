package com.dao;

import com.entity.ZhuanyefuzerenEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ZhuanyefuzerenVO;
import com.entity.view.ZhuanyefuzerenView;


/**
 * 专业负责人
 * 
 * @author 
 * @email 
 * @date 2022-04-19 21:55:27
 */
public interface ZhuanyefuzerenDao extends BaseMapper<ZhuanyefuzerenEntity> {
	
	List<ZhuanyefuzerenVO> selectListVO(@Param("ew") Wrapper<ZhuanyefuzerenEntity> wrapper);
	
	ZhuanyefuzerenVO selectVO(@Param("ew") Wrapper<ZhuanyefuzerenEntity> wrapper);
	
	List<ZhuanyefuzerenView> selectListView(@Param("ew") Wrapper<ZhuanyefuzerenEntity> wrapper);

	List<ZhuanyefuzerenView> selectListView(Pagination page,@Param("ew") Wrapper<ZhuanyefuzerenEntity> wrapper);
	
	ZhuanyefuzerenView selectView(@Param("ew") Wrapper<ZhuanyefuzerenEntity> wrapper);
	

}
