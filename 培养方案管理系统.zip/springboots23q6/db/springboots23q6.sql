-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: localhost    Database: springboots23q6
-- ------------------------------------------------------
-- Server version	5.7.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `springboots23q6`
--

/*!40000 DROP DATABASE IF EXISTS `springboots23q6`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `springboots23q6` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `springboots23q6`;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) NOT NULL COMMENT '配置参数名称',
  `value` varchar(100) DEFAULT NULL COMMENT '配置参数值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='配置文件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'picture1','upload/picture1.jpg'),(2,'picture2','upload/picture2.jpg'),(3,'picture3','upload/picture3.jpg');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jiaoshi`
--

DROP TABLE IF EXISTS `jiaoshi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jiaoshi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `jiaoshigonghao` varchar(200) NOT NULL COMMENT '教师工号',
  `mima` varchar(200) NOT NULL COMMENT '密码',
  `jiaoshixingming` varchar(200) NOT NULL COMMENT '教师姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `zhuanye` varchar(200) NOT NULL COMMENT '专业',
  `nianji` varchar(200) NOT NULL COMMENT '年级',
  `zhicheng` varchar(200) DEFAULT NULL COMMENT '职称',
  `lianxidianhua` varchar(200) DEFAULT NULL COMMENT '联系电话',
  `fuzerenzhanghao` varchar(200) DEFAULT NULL COMMENT '负责人账号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jiaoshigonghao` (`jiaoshigonghao`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='教师';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jiaoshi`
--

LOCK TABLES `jiaoshi` WRITE;
/*!40000 ALTER TABLE `jiaoshi` DISABLE KEYS */;
INSERT INTO `jiaoshi` VALUES (51,'2022-04-19 13:55:39','教师工号1','123456','教师姓名1','男','专业1','年级1','职称1','13823888881','负责人账号1'),(52,'2022-04-19 13:55:39','教师工号2','123456','教师姓名2','男','专业2','年级2','职称2','13823888882','负责人账号2'),(53,'2022-04-19 13:55:39','教师工号3','123456','教师姓名3','男','专业3','年级3','职称3','13823888883','负责人账号3'),(54,'2022-04-19 13:55:39','教师工号4','123456','教师姓名4','男','专业4','年级4','职称4','13823888884','负责人账号4'),(55,'2022-04-19 13:55:39','教师工号5','123456','教师姓名5','男','专业5','年级5','职称5','13823888885','负责人账号5'),(56,'2022-04-19 13:55:39','教师工号6','123456','教师姓名6','男','专业6','年级6','职称6','13823888886','负责人账号6');
/*!40000 ALTER TABLE `jiaoshi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kecheng`
--

DROP TABLE IF EXISTS `kecheng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kecheng` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `kecheng` varchar(200) NOT NULL COMMENT '课程',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kecheng` (`kecheng`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='课程';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kecheng`
--

LOCK TABLES `kecheng` WRITE;
/*!40000 ALTER TABLE `kecheng` DISABLE KEYS */;
INSERT INTO `kecheng` VALUES (11,'2022-04-19 13:55:39','课程1'),(12,'2022-04-19 13:55:39','课程2'),(13,'2022-04-19 13:55:39','课程3'),(14,'2022-04-19 13:55:39','课程4'),(15,'2022-04-19 13:55:39','课程5'),(16,'2022-04-19 13:55:39','课程6');
/*!40000 ALTER TABLE `kecheng` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kechengxinxi`
--

DROP TABLE IF EXISTS `kechengxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kechengxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `kecheng` varchar(200) NOT NULL COMMENT '课程',
  `jiaoshigonghao` varchar(200) NOT NULL COMMENT '教师工号',
  `jiaoshixingming` varchar(200) DEFAULT NULL COMMENT '教师姓名',
  `zhuanye` varchar(200) DEFAULT NULL COMMENT '专业',
  `nianji` varchar(200) DEFAULT NULL COMMENT '年级',
  `fuzerenzhanghao` varchar(200) DEFAULT NULL COMMENT '负责人账号',
  `xueqi` varchar(200) DEFAULT NULL COMMENT '学期',
  `kechengshuoming` longtext COMMENT '课程说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COMMENT='课程信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kechengxinxi`
--

LOCK TABLES `kechengxinxi` WRITE;
/*!40000 ALTER TABLE `kechengxinxi` DISABLE KEYS */;
INSERT INTO `kechengxinxi` VALUES (71,'2022-04-19 13:55:39','课程1','教师工号1','教师姓名1','专业1','年级1','负责人账号1','学期1','课程说明1'),(72,'2022-04-19 13:55:39','课程2','教师工号2','教师姓名2','专业2','年级2','负责人账号2','学期2','课程说明2'),(73,'2022-04-19 13:55:39','课程3','教师工号3','教师姓名3','专业3','年级3','负责人账号3','学期3','课程说明3'),(74,'2022-04-19 13:55:39','课程4','教师工号4','教师姓名4','专业4','年级4','负责人账号4','学期4','课程说明4'),(75,'2022-04-19 13:55:39','课程5','教师工号5','教师姓名5','专业5','年级5','负责人账号5','学期5','课程说明5'),(76,'2022-04-19 13:55:39','课程6','教师工号6','教师姓名6','专业6','年级6','负责人账号6','学期6','课程说明6');
/*!40000 ALTER TABLE `kechengxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nianji`
--

DROP TABLE IF EXISTS `nianji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nianji` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `nianji` varchar(200) NOT NULL COMMENT '年级',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nianji` (`nianji`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COMMENT='年级';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nianji`
--

LOCK TABLES `nianji` WRITE;
/*!40000 ALTER TABLE `nianji` DISABLE KEYS */;
INSERT INTO `nianji` VALUES (31,'2022-04-19 13:55:39','年级1'),(32,'2022-04-19 13:55:39','年级2'),(33,'2022-04-19 13:55:39','年级3'),(34,'2022-04-19 13:55:39','年级4'),(35,'2022-04-19 13:55:39','年级5'),(36,'2022-04-19 13:55:39','年级6');
/*!40000 ALTER TABLE `nianji` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peiyangfangan`
--

DROP TABLE IF EXISTS `peiyangfangan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peiyangfangan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fanganmingcheng` varchar(200) NOT NULL COMMENT '方案名称',
  `fanganneirong` longtext COMMENT '方案内容',
  `fanganwenjian` varchar(200) DEFAULT NULL COMMENT '方案文件',
  `fuzerenzhanghao` varchar(200) DEFAULT NULL COMMENT '负责人账号',
  `fuzerenxingming` varchar(200) DEFAULT NULL COMMENT '负责人姓名',
  `lianxifangshi` varchar(200) DEFAULT NULL COMMENT '联系方式',
  `jiaoshigonghao` varchar(200) NOT NULL COMMENT '教师工号',
  `jiaoshixingming` varchar(200) DEFAULT NULL COMMENT '教师姓名',
  `lianxidianhua` varchar(200) DEFAULT NULL COMMENT '联系电话',
  `zhuanye` varchar(200) DEFAULT NULL COMMENT '专业',
  `nianji` varchar(200) DEFAULT NULL COMMENT '年级',
  `crossuserid` bigint(20) DEFAULT NULL COMMENT '跨表用户id',
  `crossrefid` bigint(20) DEFAULT NULL COMMENT '跨表主键id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COMMENT='培养方案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peiyangfangan`
--

LOCK TABLES `peiyangfangan` WRITE;
/*!40000 ALTER TABLE `peiyangfangan` DISABLE KEYS */;
INSERT INTO `peiyangfangan` VALUES (61,'2022-04-19 13:55:39','方案名称1','方案内容1','','负责人账号1','负责人姓名1','联系方式1','教师工号1','教师姓名1','联系电话1','专业1','年级1',1,1),(62,'2022-04-19 13:55:39','方案名称2','方案内容2','','负责人账号2','负责人姓名2','联系方式2','教师工号2','教师姓名2','联系电话2','专业2','年级2',2,2),(63,'2022-04-19 13:55:39','方案名称3','方案内容3','','负责人账号3','负责人姓名3','联系方式3','教师工号3','教师姓名3','联系电话3','专业3','年级3',3,3),(64,'2022-04-19 13:55:39','方案名称4','方案内容4','','负责人账号4','负责人姓名4','联系方式4','教师工号4','教师姓名4','联系电话4','专业4','年级4',4,4),(65,'2022-04-19 13:55:39','方案名称5','方案内容5','','负责人账号5','负责人姓名5','联系方式5','教师工号5','教师姓名5','联系电话5','专业5','年级5',5,5),(66,'2022-04-19 13:55:39','方案名称6','方案内容6','','负责人账号6','负责人姓名6','联系方式6','教师工号6','教师姓名6','联系电话6','专业6','年级6',6,6);
/*!40000 ALTER TABLE `peiyangfangan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `tablename` varchar(100) DEFAULT NULL COMMENT '表名',
  `role` varchar(100) DEFAULT NULL COMMENT '角色',
  `token` varchar(200) NOT NULL COMMENT '密码',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  `expiratedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='token表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
INSERT INTO `token` VALUES (1,1,'abo','users','管理员','h237pby93fh7wl1hpu2hgs40hg95n4eh','2022-04-19 14:03:27','2022-04-19 15:03:27');
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `role` varchar(100) DEFAULT '管理员' COMMENT '角色',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'abo','abo','管理员','2022-04-19 13:55:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zhuanye`
--

DROP TABLE IF EXISTS `zhuanye`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zhuanye` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `zhuanye` varchar(200) NOT NULL COMMENT '专业',
  PRIMARY KEY (`id`),
  UNIQUE KEY `zhuanye` (`zhuanye`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='专业';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zhuanye`
--

LOCK TABLES `zhuanye` WRITE;
/*!40000 ALTER TABLE `zhuanye` DISABLE KEYS */;
INSERT INTO `zhuanye` VALUES (21,'2022-04-19 13:55:39','专业1'),(22,'2022-04-19 13:55:39','专业2'),(23,'2022-04-19 13:55:39','专业3'),(24,'2022-04-19 13:55:39','专业4'),(25,'2022-04-19 13:55:39','专业5'),(26,'2022-04-19 13:55:39','专业6');
/*!40000 ALTER TABLE `zhuanye` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zhuanyefuzeren`
--

DROP TABLE IF EXISTS `zhuanyefuzeren`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zhuanyefuzeren` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fuzerenzhanghao` varchar(200) NOT NULL COMMENT '负责人账号',
  `mima` varchar(200) NOT NULL COMMENT '密码',
  `fuzerenxingming` varchar(200) NOT NULL COMMENT '负责人姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `zhuanye` varchar(200) DEFAULT NULL COMMENT '专业',
  `zhiwei` varchar(200) DEFAULT NULL COMMENT '职位',
  `lianxifangshi` varchar(200) DEFAULT NULL COMMENT '联系方式',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fuzerenzhanghao` (`fuzerenzhanghao`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='专业负责人';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zhuanyefuzeren`
--

LOCK TABLES `zhuanyefuzeren` WRITE;
/*!40000 ALTER TABLE `zhuanyefuzeren` DISABLE KEYS */;
INSERT INTO `zhuanyefuzeren` VALUES (41,'2022-04-19 13:55:39','负责人账号1','123456','负责人姓名1','男','专业1','职位1','13823888881'),(42,'2022-04-19 13:55:39','负责人账号2','123456','负责人姓名2','男','专业2','职位2','13823888882'),(43,'2022-04-19 13:55:39','负责人账号3','123456','负责人姓名3','男','专业3','职位3','13823888883'),(44,'2022-04-19 13:55:39','负责人账号4','123456','负责人姓名4','男','专业4','职位4','13823888884'),(45,'2022-04-19 13:55:39','负责人账号5','123456','负责人姓名5','男','专业5','职位5','13823888885'),(46,'2022-04-19 13:55:39','负责人账号6','123456','负责人姓名6','男','专业6','职位6','13823888886');
/*!40000 ALTER TABLE `zhuanyefuzeren` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-21 10:03:08
